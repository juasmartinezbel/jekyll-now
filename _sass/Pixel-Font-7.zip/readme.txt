
True Type Font: Pixel Font-7 version 1.0


EULA
-==-
The fonts Pixel Font-7 is freeware for home using.


DESCRIPTION
-=========-
This font based on bitmap font created for freeware original strategic game Mars Soldiers-7.
http://www.styleseven.com/php/get_product.php?product=Mars%20Soldiers-7
Latin and Cyrillic code pages are supported.

Files in pixel_font-7.zip:
       	readme.txt     			this file.
        pixel font-7.ttf    		pixel font-7 regular font
	pixel font-7_windows_1251.fon   pixel font-7 in windows "FON" format Cyrillic codepage
	pixel font-7_windows_1252.fon   pixel font-7 in windows "FON" format Latin codepage
	pixel font-7 for game.bmp	original view used in game
	pixel_font-7_screen.png		preview image

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-=================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


WHAT'S NEW?
-=========-
 Version 2.0 (December 7 2012)
  * Lower case letters are changed;
  * Fixed minor bugs.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: November 14 2012